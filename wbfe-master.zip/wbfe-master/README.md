# Temporary White Buffalo Web Site

Front facing website for white paper and launch.

## Getting Started

- npm i
- npm start
